package com.mikias.practice.sem3_android_practical;

//required importations for the application
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //method that runs when this current activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //creating variables that represent the UI elements in the acitivity_main xml file
        TextView textView = findViewById(R.id.tview);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);

        //creating an intent object that connects this class with the MyService class
        Intent intent = new Intent(MainActivity.this,MyService.class);


        //event listener that performs an action once btn1 is clicked
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //starts the service
                startService(intent);
                //Displays a message indicating that the service was started
                Toast.makeText(MainActivity.this, "Service Started", Toast.LENGTH_SHORT).show();
            }
        });

        //event listener that performs an action once btn2 is clicked
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //stops the service
                stopService(intent);
                //Displays a message indicating that the service was stopped
                Toast.makeText(MainActivity.this, "Service Stopped", Toast.LENGTH_SHORT).show();
            }
        });

    }
}