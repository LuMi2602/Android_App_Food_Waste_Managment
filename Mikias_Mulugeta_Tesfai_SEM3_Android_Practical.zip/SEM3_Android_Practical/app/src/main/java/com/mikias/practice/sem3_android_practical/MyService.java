package com.mikias.practice.sem3_android_practical;

//required importations for the application
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;


import androidx.annotation.Nullable;

public class MyService extends Service {


    //Method that runs when the service is started
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        //creating an intent object that connects this class with the MainActivity class
        Intent intent1 = new Intent(this,MainActivity.class);
         startService(intent1);
        return super.onStartCommand(intent, flags, startId);
    }


    //implementing the required onBind method when creating a service class
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


}
